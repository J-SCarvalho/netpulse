import html
import csv
import time
from pathlib import Path

def generate(c,client_id,directory,now=None):
    now=time.time() if now is None else now
    rows=c.execute('SELECT * FROM samples WHERE client_id=? AND ts>=? AND ts<=? ORDER BY ts',(client_id,now-21600,now)).fetchall()
    dest=Path(directory);dest.mkdir(parents=True,exist_ok=True)
    name=f'report-{client_id}-{int(now)}';charts=[]
    for kind in sorted(set(r['kind'] for r in rows)):
        group=[r for r in rows if r['kind']==kind]
        good=[r for r in group if r['status']=='completed' and r['value'] is not None]
        if not good:
            charts.append('<h2>'+html.escape(kind)+'</h2><p>Sem dados válidos</p>');continue
        vals=[r['value'] for r in good];lo,hi=min(vals),max(vals)
        points=[(40+(r['ts']-(now-21600))/21600*720,220-(r['value']-lo)/(hi-lo or 1)*180) for r in good]
        poly=' '.join(f'{x},{y}' for x,y in points)
        marks=''.join(f'<circle cx="{x}" cy="{y}" r="5" fill="red"><title>{time.ctime(good[i]["ts"])}: {vals[i]}</title></circle>' for i,(x,y) in enumerate(points) if vals[i] in (lo,hi))
        charts.append(f'<h2>{html.escape(kind)}</h2><p>Mínimo {lo:.2f}; máximo {hi:.2f}; média {sum(vals)/len(vals):.2f}</p><svg viewBox="0 0 800 260"><polyline points="{poly}" fill="none" stroke="#00a8e3"/>{marks}</svg>')
    fields=['ts','device_id','port','kind','value','status','detail']
    with (dest/(name+'.csv')).open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(fields);w.writerows([[r[k] for k in fields] for r in rows])
    table=''.join('<tr>'+''.join('<td>'+html.escape(str(r[k]))+'</td>' for k in fields)+'</tr>' for r in rows)
    (dest/(name+'.html')).write_text('<!doctype html><meta charset="utf-8"><h1>NetPulse — últimas seis horas</h1>'+''.join(charts)+'<table><tr>'+''.join('<th>'+k+'</th>' for k in fields)+'</tr>'+table+'</table>',encoding='utf-8')
    c.execute('INSERT INTO reports(client_id,ts,path) VALUES(?,?,?)',(client_id,now,name+'.html'))
    return name
