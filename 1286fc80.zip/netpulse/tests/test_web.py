import os
import tempfile
import unittest
from werkzeug.security import generate_password_hash
class WebTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();os.environ['NETPULSE_DB']=self.tmp.name+'/db.sqlite';os.environ['NETPULSE_SECRET_KEY']='test-key';os.environ['NETPULSE_PASSWORD_HASH']=generate_password_hash('test-password')
  from app import app
  app.config['TESTING']=True;self.client=app.test_client()
 def tearDown(self):self.tmp.cleanup()
 def login(self):
  self.client.get('/login')
  with self.client.session_transaction() as s:token=s['csrf']
  return self.client.post('/login',data={'username':'admin','password':'test-password','csrf':token})
 def test_protected(self):self.assertEqual(self.client.get('/').status_code,302)
 def test_csrf(self):self.client.get('/login');self.assertEqual(self.client.post('/login',data={}).status_code,403)
 def test_pages(self):
  self.login()
  for p in ['/','/clients','/devices','/alerts','/reports']:self.assertEqual(self.client.get(p).status_code,200)
 def test_create_client(self):
  self.login()
  with self.client.session_transaction() as s:t=s['csrf']
  r=self.client.post('/clients',data={'csrf':t,'name':'Teste','download':500,'upload':100,'agent':'local'})
  self.assertEqual(r.status_code,302)
