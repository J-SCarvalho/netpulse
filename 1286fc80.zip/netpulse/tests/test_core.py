import unittest
import tempfile
from pathlib import Path
from core import connect,alarm,rate,port_events
from reporting import generate
class Tests(unittest.TestCase):
 def setUp(self):self.c=connect(':memory:')
 def test_rate(self):self.assertEqual(rate(0,750000000,60,1000),10)
 def test_reset(self):self.assertIsNone(rate(100,0,60,1000))
 def test_alert_dedupe(self):
  alarm(self.c,'x','x',True);alarm(self.c,'x','x',True)
  self.assertEqual(self.c.execute('SELECT COUNT(*) FROM alerts').fetchone()[0],1)
 def test_recovery_acknowledged(self):
  alarm(self.c,'x','x',True);self.c.execute("UPDATE alerts SET status='acknowledged'");alarm(self.c,'x','x',False)
  self.assertEqual(self.c.execute('SELECT status FROM alerts').fetchone()[0],'resolved')
 def test_flapping(self):
  for t,oper in [(0,'1'),(60,'2'),(120,'1'),(180,'2')]:port_events(self.c,1,'1',t*1000,t*1000,1000,'0',oper,0,0,t)
  self.assertIsNotNone(self.c.execute("SELECT id FROM alerts WHERE key LIKE '%flap' AND status='open'").fetchone())
 def test_discontinuity(self):
  port_events(self.c,1,'1',0,0,1000,'0','1',0,0,0)
  self.assertIsNone(port_events(self.c,1,'1',10000,10000,1000,'1','1',0,0,60))
 def test_threshold(self):
  self.assertTrue(150<=500*.3);self.assertFalse(151<=500*.3);self.assertFalse(45>45);self.assertTrue(45.1>45)
 def test_report(self):
  self.c.execute("INSERT INTO samples(client_id,kind,value,status,ts) VALUES(1,'download',150,'completed',100)")
  self.c.execute("INSERT INTO samples(client_id,kind,value,status,ts) VALUES(1,'download',NULL,'failed',200)")
  with tempfile.TemporaryDirectory() as d:
   name=generate(self.c,1,d,300);text=Path(d,name+'.html').read_text()
   self.assertIn('<svg',text);self.assertIn('failed',text);self.assertIn('150.00',text);self.assertTrue(Path(d,name+'.csv').exists())
if __name__=='__main__':unittest.main()
