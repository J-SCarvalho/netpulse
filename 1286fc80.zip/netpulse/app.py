import os
import secrets
import time
import ipaddress
from pathlib import Path
from flask import Flask,request,session,redirect,render_template,abort,send_from_directory
from werkzeug.security import check_password_hash
from core import connect

app=Flask(__name__)
app.secret_key=os.environ['NETPULSE_SECRET_KEY']
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Strict',SESSION_COOKIE_SECURE=os.getenv('NETPULSE_HTTPS')=='1',MAX_CONTENT_LENGTH=65536)
attempts={}
def db():return connect(os.getenv('NETPULSE_DB','netpulse.db'))
@app.before_request
def guard():
    if request.endpoint=='static':return
    if request.endpoint!='login' and not session.get('user'):return redirect('/login')
    if request.method=='POST' and not secrets.compare_digest(request.form.get('csrf',''),session.get('csrf','missing')):abort(403)
@app.after_request
def headers(r):
    r.headers['X-Content-Type-Options']='nosniff';r.headers['X-Frame-Options']='DENY';r.headers['Content-Security-Policy']="default-src 'self'; style-src 'self'; img-src 'self' data:; frame-src 'self'; form-action 'self'"
    return r
@app.route('/login',methods=['GET','POST'])
def login():
    session.setdefault('csrf',secrets.token_hex(32));error=''
    if request.method=='POST':
        key=request.remote_addr;recent=[t for t in attempts.get(key,[]) if time.time()-t<900]
        if len(recent)>=5:abort(429)
        if request.form.get('username')==os.getenv('NETPULSE_ADMIN','admin') and check_password_hash(os.environ['NETPULSE_PASSWORD_HASH'],request.form.get('password','')):
            session.clear();session['user']=os.getenv('NETPULSE_ADMIN','admin');session['csrf']=secrets.token_hex(32);attempts.pop(key,None);return redirect('/')
        attempts[key]=recent+[time.time()];error='Credenciais inválidas'
    return render_template('login.html',error=error)
@app.post('/logout')
def logout():session.clear();return redirect('/login')
@app.route('/')
@app.route('/<page>')
def page(page='dashboard'):
    if page not in ('dashboard','clients','devices','alerts','reports'):abort(404)
    with db() as c:
        rows={t:c.execute('SELECT * FROM '+t+' ORDER BY id DESC LIMIT 200').fetchall() for t in ('clients','devices','alerts','reports','samples')}
    return render_template('page.html',page=page,rows=rows)
@app.post('/clients')
def clients():
    f=request.form
    try:
        down=float(f['download']);up=float(f['upload']);ip=f.get('iperf','').strip()
        if down<=0 or up<=0 or not f['name'].strip():abort(400)
        if ip:ipaddress.ip_address(ip)
        with db() as c:c.execute('INSERT INTO clients(name,download,upload,agent,iperf) VALUES(?,?,?,?,?)',(f['name'],down,up,f.get('agent','local'),ip))
    except (ValueError,KeyError):abort(400)
    return redirect('/clients')
@app.post('/devices')
def devices():
    f=request.form
    try:
        ipaddress.ip_address(f['ip']);client=int(f['client_id'])
        if f['kind'] not in ('switch','router','firewall','access_point'):abort(400)
        with db() as c:
            if not c.execute('SELECT id FROM clients WHERE id=?',(client,)).fetchone():abort(400)
            c.execute('INSERT INTO devices(client_id,name,kind,ip,credential) VALUES(?,?,?,?,?)',(client,f['name'],f['kind'],f['ip'],f['credential']))
    except (KeyError,ValueError):abort(400)
    return redirect('/devices')
@app.post('/alerts/<int:ident>/<action>')
def alerts(ident,action):
    if action not in ('acknowledged','resolved'):abort(400)
    with db() as c:c.execute('UPDATE alerts SET status=? WHERE id=?',(action,ident))
    return redirect('/alerts')
@app.get('/reports/<int:ident>')
def reports(ident):
    with db() as c:r=c.execute('SELECT * FROM reports WHERE id=?',(ident,)).fetchone()
    if not r:abort(404)
    return send_from_directory(Path(os.getenv('NETPULSE_REPORTS','reports')).resolve(),r['path'])
if __name__=='__main__':app.run(host='127.0.0.1',port=5000,debug=False)
