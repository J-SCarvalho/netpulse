import sqlite3
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY,name TEXT NOT NULL,download REAL NOT NULL CHECK(download>0),upload REAL NOT NULL CHECK(upload>0),agent TEXT NOT NULL,iperf TEXT);
CREATE TABLE IF NOT EXISTS devices(id INTEGER PRIMARY KEY,client_id INTEGER NOT NULL REFERENCES clients(id),name TEXT NOT NULL,kind TEXT NOT NULL,ip TEXT NOT NULL,credential TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS samples(id INTEGER PRIMARY KEY,client_id INTEGER,device_id INTEGER,port TEXT,kind TEXT,value REAL,status TEXT,detail TEXT,ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY,key TEXT NOT NULL,title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',ts REAL NOT NULL,resolved REAL);
CREATE UNIQUE INDEX IF NOT EXISTS active_alert ON alerts(key) WHERE status IN ('open','acknowledged');
CREATE TABLE IF NOT EXISTS ports(device_id INTEGER,idx TEXT,in_oct INTEGER,out_oct INTEGER,ts REAL,discontinuity TEXT,oper TEXT,errors INTEGER,discards INTEGER,changes TEXT,PRIMARY KEY(device_id,idx));
CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY,client_id INTEGER,ts REAL,path TEXT);
CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY,body TEXT,attempts INTEGER DEFAULT 0,sent REAL);
"""
def connect(path):
    c=sqlite3.connect(path,timeout=30);c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON');c.execute('PRAGMA journal_mode=WAL');c.executescript(SCHEMA)
    return c

def alarm(c,key,title,bad,now=None):
    now=time.time() if now is None else now
    found=c.execute("SELECT id FROM alerts WHERE key=? AND status IN ('open','acknowledged')",(key,)).fetchone()
    if bad and not found:
        c.execute("INSERT INTO alerts(key,title,ts) VALUES(?,?,?)",(key,title,now))
        c.execute('INSERT INTO outbox(body) VALUES(?)',('ALERTA: '+title,))
    elif not bad and found:
        c.execute("UPDATE alerts SET status='resolved',resolved=? WHERE id=?",(now,found['id']))
        c.execute('INSERT INTO outbox(body) VALUES(?)',('RECUPERAÇÃO: '+title,))

def rate(old,new,seconds,capacity):
    if seconds<=0 or capacity<=0 or new<old:return None
    return (new-old)*8/seconds/1e6/capacity*100

def port_events(c,device,idx,in_oct,out_oct,speed,discontinuity,oper,errors,discards,now):
    import json
    old=c.execute('SELECT * FROM ports WHERE device_id=? AND idx=?',(device,idx)).fetchone()
    changes=[];usage=None;error_delta=discard_delta=0
    if old:
        changes=[t for t in json.loads(old['changes']) if now-t<=600]
        if old['oper']!=oper:changes.append(now)
        if old['discontinuity']==discontinuity:
            ri=rate(old['in_oct'],in_oct,now-old['ts'],speed)
            ro=rate(old['out_oct'],out_oct,now-old['ts'],speed)
            if ri is not None and ro is not None:usage=max(ri,ro)
            error_delta=max(0,errors-old['errors']);discard_delta=max(0,discards-old['discards'])
    key=f'device:{device}:port:{idx}'
    alarm(c,key+':down',f'Equipamento {device}, porta {idx}: down',oper!='1',now)
    alarm(c,key+':flap',f'Equipamento {device}, porta {idx}: intermitência',len(changes)>=3,now)
    if usage is not None:alarm(c,key+':load',f'Equipamento {device}, porta {idx}: utilização {usage:.1f}%',usage>45,now)
    alarm(c,key+':errors',f'Equipamento {device}, porta {idx}: erros/descartes',error_delta>0 or discard_delta>0,now)
    c.execute('INSERT OR REPLACE INTO ports VALUES(?,?,?,?,?,?,?,?,?,?)',(device,idx,in_oct,out_oct,now,discontinuity,oper,errors,discards,json.dumps(changes)))
    return usage
