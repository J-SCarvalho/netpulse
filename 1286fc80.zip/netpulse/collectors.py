import json
import os
import subprocess
import urllib.request
import ipaddress
from pathlib import Path

def command(argv,timeout=30,env=None):
    p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout,env=env)
    if p.returncode:raise RuntimeError('Coleta falhou: '+argv[0])
    return p.stdout

def wan():
    data=json.loads(command(['speedtest','--format=json'],180))
    return data['download']['bandwidth']*8/1e6,data['upload']['bandwidth']*8/1e6

def lan(host):
    ipaddress.ip_address(host)
    data=json.loads(command(['iperf3','-c',host,'-t','10','-J'],30))
    return data['end']['sum_received']['bits_per_second']/1e6

def snmp(device):
    ipaddress.ip_address(device['ip'])
    key=device['credential']
    if not key.replace('_','').isalnum():raise ValueError('Referência de credencial inválida')
    directory=Path(os.environ['NETPULSE_SNMP_CONFIG_ROOT'])/key
    if not (directory/'snmp.conf').is_file():raise ValueError('Configuração SNMPv3 ausente')
    env=dict(os.environ,SNMPCONFPATH=str(directory))
    def walk(oid):
        raw=command(['snmpbulkwalk','-v','3','-l','authPriv','-On','-Oq','-t','2','-r','1',device['ip'],oid],30,env)
        result={}
        for line in raw.splitlines():
            parts=line.split(None,1)
            if len(parts)==2:
                idx=parts[0].split('.')[-1];value=parts[1].strip('"')
                try:result[idx]=int(value)
                except ValueError:result[idx]=value
        return result
    roots={'admin':'.1.3.6.1.2.1.2.2.1.7','oper':'.1.3.6.1.2.1.2.2.1.8','speed':'.1.3.6.1.2.1.31.1.1.1.15','in':'.1.3.6.1.2.1.31.1.1.1.6','out':'.1.3.6.1.2.1.31.1.1.1.10','discontinuity':'.1.3.6.1.2.1.31.1.1.1.19','errors_in':'.1.3.6.1.2.1.2.2.1.14','errors_out':'.1.3.6.1.2.1.2.2.1.20','discards_in':'.1.3.6.1.2.1.2.2.1.13','discards_out':'.1.3.6.1.2.1.2.2.1.19'}
    return {k:walk(v) for k,v in roots.items()}
