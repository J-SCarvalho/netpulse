import os
import time
import logging
import smtplib
import ssl
from email.message import EmailMessage
from core import connect,alarm,port_events
from collectors import wan,lan,snmp
from reporting import generate

def sample(c,client,kind,value=None,status='completed',detail='',device=None,port=None):
    c.execute('INSERT INTO samples(client_id,device_id,port,kind,value,status,detail,ts) VALUES(?,?,?,?,?,?,?,?)',(client,device,port,kind,value,status,detail,time.time()))

def poll(c,d):
    try:
        data=snmp(d);alarm(c,f'device:{d["id"]}:collection',f'{d["name"]}: coleta indisponível',False)
        for idx,admin in data['admin'].items():
            if admin!=1:continue
            required=['oper','speed','in','out','discontinuity','errors_in','errors_out','discards_in','discards_out']
            if any(idx not in data[k] for k in required):
                sample(c,d['client_id'],'port_utilization',status='unknown',detail='OID ausente',device=d['id'],port=idx);continue
            usage=port_events(c,d['id'],idx,data['in'][idx],data['out'][idx],data['speed'][idx],str(data['discontinuity'][idx]),str(data['oper'][idx]),data['errors_in'][idx]+data['errors_out'][idx],data['discards_in'][idx]+data['discards_out'][idx],time.time())
            sample(c,d['client_id'],'port_utilization',usage,'completed' if usage is not None else 'unknown',device=d['id'],port=idx)
    except Exception:
        sample(c,d['client_id'],'device_collection',status='failed',device=d['id'],detail='SNMP indisponível; não confirma equipamento down')
        alarm(c,f'device:{d["id"]}:collection',f'{d["name"]}: coleta indisponível',True)

def notify(c):
    if not os.getenv('NETPULSE_SMTP_HOST'):return
    for r in c.execute('SELECT * FROM outbox WHERE sent IS NULL AND attempts<5').fetchall():
        try:
            msg=EmailMessage();msg['Subject']='NetPulse';msg['From']=os.environ['NETPULSE_MAIL_FROM'];msg['To']=os.environ['NETPULSE_MAIL_TO'];msg.set_content(r['body'])
            with smtplib.SMTP(os.environ['NETPULSE_SMTP_HOST'],int(os.getenv('NETPULSE_SMTP_PORT','587')),timeout=15) as s:
                s.starttls(context=ssl.create_default_context())
                if os.getenv('NETPULSE_SMTP_USER'):s.login(os.environ['NETPULSE_SMTP_USER'],os.environ['NETPULSE_SMTP_PASSWORD'])
                s.send_message(msg)
            c.execute('UPDATE outbox SET sent=? WHERE id=?',(time.time(),r['id']))
        except Exception:
            c.execute('UPDATE outbox SET attempts=attempts+1 WHERE id=?',(r['id'],));logging.exception('Notificação falhou')

def run():
    import fcntl
    lock=open(os.getenv('NETPULSE_WORKER_LOCK','netpulse-worker.lock'),'w')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    c=connect(os.getenv('NETPULSE_DB','netpulse.db'));due={'wan':0,'lan':0,'ports':0,'report':time.monotonic()+21600}
    intervals={'wan':3600,'lan':1800,'ports':60,'report':21600}
    while True:
        now=time.monotonic()
        for task in due:
            if now<due[task]:continue
            due[task]=now+intervals[task]
            for cl in c.execute('SELECT * FROM clients').fetchall():
                try:
                    if task in ('wan','lan') and cl['agent']!=os.getenv('NETPULSE_AGENT_ID','local'):continue
                    if task=='wan':
                        down,up=wan()
                        for kind,value,contract in [('download',down,cl['download']),('upload',up,cl['upload'])]:
                            sample(c,cl['id'],kind,value);alarm(c,f'client:{cl["id"]}:{kind}',f'{cl["name"]}: {kind} <=30% contratado',value<=contract*.3)
                    elif task=='lan' and cl['iperf']:sample(c,cl['id'],'iperf_throughput',lan(cl['iperf']))
                    elif task=='ports':
                        for d in c.execute('SELECT * FROM devices WHERE client_id=?',(cl['id'],)).fetchall():poll(c,d)
                    elif task=='report':
                        name=generate(c,cl['id'],os.getenv('NETPULSE_REPORTS','reports'))
                        c.execute('INSERT INTO outbox(body) VALUES(?)',(f'Relatório gerado para {cl["name"]}: {name}',))
                except Exception:
                    sample(c,cl['id'],task,status='failed',detail='Medição falhou; sem valor estimado');logging.exception('Tarefa falhou')
                c.commit()
        notify(c);c.commit();time.sleep(1)
if __name__=='__main__':run()
