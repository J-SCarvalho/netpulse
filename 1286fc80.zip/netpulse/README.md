# NetPulse — MVP reconstruído

## Estado real
Aplicativo Flask, SQLite, páginas de clientes/equipamentos/alertas/relatórios,
autenticação administrativa, CSRF, limite básico de tentativas, worker separado,
SNMPv3 por Net-SNMP, speedtest CLI, iperf3, alertas com deduplicação/recuperação,
fila de e-mails STARTTLS e relatórios HTML/SVG + CSV.
Não é implantação em produção. Não foi validado em equipamentos reais.

## Instalação Linux
Python 3.12+. Instale Net-SNMP (snmpbulkwalk), iperf3 e Speedtest CLI da Ookla.
O speedtest-cli Python NÃO é o comando compatível com este parser.
Aceite os termos do Speedtest CLI conscientemente, antes de ativar o worker.
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export NETPULSE_SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export NETPULSE_PASSWORD_HASH="$(python -c 'from werkzeug.security import generate_password_hash; import getpass; print(generate_password_hash(getpass.getpass()))')"
python app.py
Em outro terminal com mesmo ambiente: python worker.py
Servidor web local: http://127.0.0.1:5000
Worker exige Linux e lock exclusivo; não inicie em vários hosts para o mesmo banco.

## SNMPv3
NETPULSE_SNMP_CONFIG_ROOT deve apontar para diretório externo ao repositório.
Cada referência cadastrada é uma subpasta com snmp.conf protegido (chmod 600).
Configure defSecurityName, defSecurityLevel authPriv, defAuthType SHA,
defAuthPassphrase, defPrivType AES e defPrivPassphrase segundo Net-SNMP instalado.
Nenhuma senha SNMP é passada na linha de comando nem salva no banco.
Somente portas administrativamente up são monitoradas. OIDs ausentes = desconhecido.
Velocidade usa ifHighSpeed; taxas usam contadores HC e discontinuityTime.
Falha SNMP indica coleta indisponível, NÃO prova equipamento down.
Erros/descartes sinalizam suspeita de gargalo; não diagnóstico causal.
Flapping: >=3 mudanças em 10 min, observadas por polling de 60s.
Eventos mais rápidos que o polling podem ser perdidos; traps/syslog ainda não implementados.

## Regras
Download e upload possuem contratos separados; alerta <=30% de cada contrato.
Porta: max(utilização entrada, saída)>45%, não soma full duplex.
WAN a cada 60 min; iperf3 a cada 30 min; portas a cada 60s; relatórios a cada 6h.
Teste iperf3 mede desempenho e NÃO aciona alerta de utilização.
Testes ativos podem consumir banda; agende com autorização do cliente.
Cadastre apenas um link por agente local. Não medir diversos clientes pelo mesmo link.
Multi-site remoto exige agentes em cada rede e transporte seguro, ainda não implementado.

## Notificações
NETPULSE_SMTP_HOST, NETPULSE_SMTP_PORT (587), NETPULSE_SMTP_USER,
NETPULSE_SMTP_PASSWORD, NETPULSE_MAIL_FROM, NETPULSE_MAIL_TO.
Sem SMTP: fila permanece pendente. Até 5 tentativas por mensagem; revisar falhas.
Relatórios disponíveis pela interface autenticada; aviso por email sem anexo.

## Segurança e limitações
Uma conta administrativa; sem RBAC/multitenancy, sem edição/exclusão de cadastros.
Use HTTPS/reverse proxy e servidor WSGI na produção; NETPULSE_HTTPS=1.
Não exponha servidor de desenvolvimento. Limite de login em memória não distribuído.
Logo original indisponível: paleta provisória azul, não identidade validada.
Nenhum deploy remoto ou upload GitHub foi realizado por este pacote.

## Testes
python -m unittest discover -s tests -v
Core/reporting podem testar sem Flask: python -m unittest discover -s tests -p test_core.py -v
CI testa também autenticação, CSRF, páginas e cadastro quando Flask está instalado.
